Scheme
{
	Colors
	{
		
	}

	Fonts
	{
		
	}

	Borders
	{
		
	}
}
