"Resource/UI/HudHealthAccount_Base.res"
{
	"CHealthAccountPanel"
	{
		"FieldName"									"CHealthAccountPanel"
		"xpos_minmode"								"88"
		"ypos_minmode"								"rs1-73"
		"delta_item_x"								"0"
		"delta_item_start_y"						"2"
		"delta_item_end_y"							"2"
		"PositiveColor"								"white"
		"NegativeColor"								"sorared"
		"delta_lifetime"							"1"
		"delta_item_font"							"QuestMediumText_Merasmus"
	}
}