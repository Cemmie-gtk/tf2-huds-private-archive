#base "loadingdialog.res"
