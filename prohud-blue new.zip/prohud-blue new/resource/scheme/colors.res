"Scheme"
{
	"Colors"
	{
		"Health Numbers"									"255 255 255 255"

		"MainTheme"										"179 216 173 255" // 179 216 173 255
		"MainThemeLowAlpha"									"179 216 173 180" // 179 216 173 180

		"Health Buff"										"187 220 229 255" // 100 180 170 255 // 186 183 182 255
		"Health Buff Target"								"187 220 229 255"
		"Health Buff Spec"									"187 220 229 255"
		"Health Buff Killer"								"187 220 229 255"

		"Health Hurt"										"255 39 38 255"
		"Health Hurt Target"								"255 39 38 255"
		"Health Hurt Spec"									"255 39 38 255"
		"Health Hurt Killer"								"255 39 38 255"

		"Orange"											"179 216 173 255"
		"OrangeDim"											"179 216 173 255"
		"LightOrange"										"179 216 173 255"
		"TFOrange"											"179 216 173 255"
		"Purple"											"137 69 99 255"

		"QuestGold"											"208 147 75 255"
		"HalloweenThemeColor2015_Light"						"238 126 17 255"
		"HalloweenThemeColor2015"							"135 54 16 255"
		"HalloweenThemeColor2015_Dark"						"108 49 21 255"
		"QuestUncommitted"									"183 147 100 255"

		"QuestMap_Bonus"									"222 217 166 255"
		"QuestMap_ActiveOrange"								"212 127 25 255"
		"QuestMap_InactiveGrey"								"100 100 100 255"
		"QuestMap_BGImages"									"56 58 60 255"

		"PartyMember1"										"124 173 255 255"
		"PartyMember2"										"99 232 167 255"
		"PartyMember3"										"229 255 121 255"
		"PartyMember4"										"232 184 99  255"
		"PartyMember5"										"255 118 108 255"
		"PartyMember6"										"255 133 255 255"

		"Red"												"255 100 100 255"
		"RedSolid"											"255 100 100 255"
		"Blue"												"90 122 143 255"
		"Yellow"											"255 255 255 255"
		"TransparentYellow"									"255 255 255 255"
		"BrightYellow"										"235 235 50 255"
		"GreenSolid"										"76 107 34 255"

		"FooterBGBlack"										"46 43 42 255"

		"White"												"255 255 255 255"
		"OffWhite"											"200 200 200 255"
		"DullWhite"											"142 142 142 255"

		"HUDBlueTeam"										"90 122 143 255"
		"HUDRedTeam"										"189 59 61 255"
		"HUDSpectator"										"130 125 125 255"
		"HUDBlueTeamSolid"									"90 122 143 255"
		"HUDRedTeamSolid"									"189 59 61 255"
		"HUDDeathWarning"									"255 100 100 255"
		"HudWhite"											"255 255 255 255"
		"HudOffWhite"										"255 255 255 255"
		"Black"												"46 43 42 255"
		"HudBlack"											"46 43 42 255"
		"ProgressBarBlue"									"91 122 142 255"

		"CreditsGreen"										"94 150 49 255"

		"Gray"												"178 178 178 255"

		"Blank"												"0 0 0 0"

		"TransparentBlack"									"20 20 20 210"
		"TransparentMediumBlack"							"0 0 0 150"
		"TransparentBlackInactive"							"15 15 15 125"
		"LightTransparentBlack"								"35 35 35 210"
		"LightTransparentBlackInactive"						"35 35 35 125"

		"HudPanelForeground"								"130 125 125 255"
		"HudPanelBackground"								"130 125 125 255"
		"HudPanelBorder"									"130 125 125 255"

		"HudProgressBarActive"								"255 255 255 255"
		"HudProgressBarInActive"							"255 255 255 255"
		"HudProgressBarActiveLow"							"255 100 100 255"
		"HudProgressBarInActiveLow"							"255 100 100 255"

		"HudTimerProgressActive"							"255 255 255 255"
		"HudTimerProgressInActive"							"46 43 42 255"
		"HudTimerProgressWarning"							"255 100 100 255"

		"HudTrainingHint"									"255 255 255 255"

		"TanDark"											"255 255 255 255"
		"TanLight"											"255 255 255 255"
		"TanDarker"											"46 43 42 255"

		"StoreDarkTan"										"130 125 125 255"
		"StoreGreen"										"76 107 34 255"

		"LowHealthRed"										"255 100 100 255"
		"ProgressOffWhite"									"255 255 255 255"
		"ProgressBackground"								"0 0 0 50"
		"HealthBgGrey"										"130 125 125 255"

		"ProgressOffWhiteTransparent"						"255 255 255 255"

		"LabelDark"											"0 0 0 255"
		"LabelTransparent"									"0 0 0 100"

		"BuildMenuActive"									"255 255 255 255"

		"DisguiseMenuIconRed"								"189 59 61 255"
		"DisguiseMenuIconBlue"								"90 122 143 255"

		"HTMLBackground"									"45 44 43 255"

		"ItemAttribLevel"									"255 255 255 255"
		"ItemAttribNeutral"									"255 255 255 255"
		"ItemAttribPositive"								"255 255 255 255"
		"ItemAttribNegative"								"255 100 100 255"

		"ItemSetName"										"225 255 15 255"
		"ItemSetItemEquipped"								"149 175 12 255"
		"ItemSetItemMissing"								"139 137 137 255"
		"ItemIsotope"										"225 255 15 255"
		"ItemBundleItem"									"149 175 12 255"
		"ItemLimitedUse"									"0 160 0 255"
		"ItemFlags"											"255 255 255 255"
		"ItemLimitedQuantity"								"225 209 0 255"

		"QualityColorNormal"								"178 178 178 255"
		"QualityColorrarity1"								"77 116 85 255"
		"QualityColorrarity2"								"141 131 75 255"
		"QualityColorrarity3"								"204 204 250 255"
		"QualityColorrarity4"								"134 80 172 255"
		"QualityColorVintage"								"71 98 145 255"
		"QualityColorUnique"								"255 215 0 255"
		"QualityColorCommunity"								"112 176 74 255"
		"QualityColorDeveloper"								"165 15 121 255"
		"QualityColorSelfMade"								"112 176 74 255"
		"QualityColorCustomized"							"71 98 145 255"
		"QualityColorStrange"								"207 106 50 255"
		"QualityColorCompleted"								"134 80 172 255"
		"QualityColorHaunted"								"56 243 171 255"
		"QualityColorCollectors"							"170 0 0 255"
		"QualityColorPaintkitWeapon"						"250 250 250 255"

		"ItemRarityDefault"									"131 126 119 255"
		"ItemRarityCommon"									"176 195 217 255"
		"ItemRarityUncommon"								"94 152 217 255"
		"ItemRarityRare"									"75 105 255 255"
		"ItemRarityMythical"								"136 71 255 255"
		"ItemRarityLegendary"								"211 44 230 255"
		"ItemRarityAncient"									"235 75 75 255"

		"ItemRarityDefault_GreyedOut"						"44 42 40 255"
		"ItemRarityCommon_GreyedOut"						"59 65 72 255"
		"ItemRarityUncommon_GreyedOut"						"31 50 72 255"
		"ItemRarityRare_GreyedOut"							"25 35 85 255"
		"ItemRarityMythical_GreyedOut"						"45 24 85 255"
		"ItemRarityLegendary_GreyedOut"						"70 15 77 255"
		"ItemRarityAncient_GreyedOut"						"78 25 25 255"

		"QualityColorNormal_GreyedOut"						"44 44 44 255"
		"QualityColorrarity1_GreyedOut"						"20 29 21 255"
		"QualityColorrarity2_GreyedOut"						"35 33 19 255"
		"QualityColorrarity3_GreyedOut"						"51 51 62 255"
		"QualityColorrarity4_GreyedOut"						"36 20 43 255"
		"QualityColorVintage_GreyedOut"						"18 25 36 255"
		"QualityColorUnique_GreyedOut"						"64 54 0  255"
		"QualityColorCommunity_GreyedOut"					"28 44 19 255"
		"QualityColorDeveloper_GreyedOut"					"41 4  30  255"
		"QualityColorSelfMade_GreyedOut"					"28 44 74 255"
		"QualityColorCustomized_GreyedOut"					"71 98 19 255"
		"QualityColorStrange_GreyedOut"						"52 27 13 255"
		"QualityColorCompleted_GreyedOut"					"34 20 43 255"
		"QualityColorHaunted_GreyedOut"						"14 61 43 255"
		"QualityColorCollectors_GreyedOut"					"60 0 0 255"
		"QualityColorPaintkitWeapon_GreyedOut"				"60 60 60 255"

		"SaleGreen"											"76 107 34 255"

		"LightRed"											"179 216 173 255"
		"LighterRed"										"179 216 173 255"
		"LighterDarkBrown"									"72 71 70 255"
		"DarkBrown"											"46 43 42 255"

		"UpgradeDefaultFg"									"255 255 255 255"
		"UpgradeDefaultBg"									"46 43 42 255"
		"UpgradeArmedFg"									"255 255 255 255"
		"UpgradeArmedBg"									"179 216 173 255"
		"UpgradeDepressedFg"								"46 43 42 255"
		"UpgradeDepressedBg"								"179 216 173 255"
		"UpgradeSelectedFg"									"46 43 42 255"
		"UpgradeSelectedBg"									"179 216 173 255"
		"UpgradeDisabledFg"									"46 43 42 255"
		"UpgradeDisabledBg"									"0 0 0 255"
	}

	"BaseSettings"
	{
		"ReplayBrowser.BgColor"								"TanDarker"
		"ReplayBrowser.Details.TitleEdit.Carat.FgColor"		"MainTheme"
		"ReplayBrowser.Button.ArmedBgColor"					"MainTheme"
		"ReplayBrowser.Button.DepressedBgColor"				"MainTheme"
		"ReplayBrowser.CollectionTitle.FgColor"				"MainTheme"
		"ReplayBrowser.Warning.FgColor"						"White"
		"ReplayBrowser.ScrollBar.SliderButton.FgColor"		"White"
		"ReplayBrowser.Search.BgColor"						"LighterDarkBrown"
		"ReplayBrowser.Search.FgColor"						"White"

		"Replay.RenderDialog.BgColor"						"TanDarker"

		"Econ.Dialog.BgColor"								"Blank"
		"Econ.Button.BgColor"								"LighterDarkBrown"
		"Econ.Button.FgColor"								"White"
		"Econ.Button.ArmedBgColor"							"MainTheme"
		"Econ.Button.ArmedFgColor"							"White"
		"Econ.Button.DepressedBgColor"						"MainTheme"
		"Econ.Button.DepressedFgColor"						"Black"

		"Econ.Button.PresetDefaultColorFg"					"White"
		"Econ.Button.PresetArmedColorFg"					"White"
		"Econ.Button.PresetDepressedColorFg"				"White"

		"Econ.Button.PresetDefaultColorBg"					"MainTheme"
		"Econ.Button.PresetArmedColorBg"					"MainTheme"
		"Econ.Button.PresetDepressedColorBg"				"MainTheme"

		"Border.Bright"										"Blank"
		"Border.Dark"										"Black"
		"Border.Selection"									"Gray"

		"Button.TextColor"									"White"
		"Button.BgColor"									"LighterDarkBrown"
		"Button.ArmedTextColor"								"White"
		"Button.ArmedBgColor"								"MainTheme"
		"Button.SelectedTextColor"							"White"
		"Button.SelectedBgColor"							"MainTheme"
		"Button.DepressedTextColor"							"Black"
		"Button.DepressedBgColor"							"MainTheme"

		"CheckButton.TextColor"								"White"
		"CheckButton.SelectedTextColor"						"White"
		"CheckButton.BgColor"								"TransparentBlack"
		"CheckButton.Border1"  								"White"
		"CheckButton.Border2" 								"White"
		"CheckButton.Check"									"White"
		"CheckButton.HighlightFgColor"						"White"

		"ComboBoxButton.ArrowColor"							"White"
		"ComboBoxButton.ArmedArrowColor"					"White"
		"ComboBoxButton.BgColor"							"Blank"
		"ComboBoxButton.DisabledBgColor"					"Blank"

		"Frame.BgColor"										"TransparentBlack"
		"Frame.OutOfFocusBgColor"							"TransparentBlack"
		"Frame.FocusTransitionEffectTime"					"0.0"
		"Frame.TransitionEffectTime"						"0.0"
		"Frame.AutoSnapRange"								"0"
		"FrameGrip.Color1"									"Blank"
		"FrameGrip.Color2"									"Blank"
		"FrameTitleButton.FgColor"							"Blank"
		"FrameTitleButton.BgColor"							"Blank"
		"FrameTitleButton.DisabledFgColor"					"Blank"
		"FrameTitleButton.DisabledBgColor"					"Blank"
		"FrameSystemButton.FgColor"							"Blank"
		"FrameSystemButton.BgColor"							"Blank"
		"FrameSystemButton.Icon"							""
		"FrameSystemButton.DisabledIcon"					""
		"FrameTitleBar.TextColor"							"MainTheme"
		"FrameTitleBar.BgColor"								"Blank"
		"FrameTitleBar.DisabledTextColor"					"MainTheme"
		"FrameTitleBar.DisabledBgColor"						"Blank"

		"GraphPanel.FgColor"								"MainTheme"
		"GraphPanel.BgColor"								"TransparentBlack"

		"Label.TextDullColor"								"White"
		"Label.TextColor"									"White"
		"Label.TextBrightColor"								"White"
		"Label.SelectedTextColor"							"White"
		"Label.BgColor"										"Blank"
		"Label.DisabledFgColor1"							"Blank"
		"Label.DisabledFgColor2"							"Black"

		"ListPanel.TextColor"								"MainTheme"
		"ListPanel.BgColor"									"TransparentBlack"
		"ListPanel.SelectedTextColor"						"Black"
		"ListPanel.SelectedBgColor"							"MainTheme"
		"ListPanel.SelectedOutOfFocusBgColor"				"MainTheme"
		"ListPanel.EmptyListInfoTextColor"					"MainTheme"

		"Menu.TextColor"									"White"
		"Menu.BgColor"										"LightTransparentBlack"
		"Menu.ArmedTextColor"								"TanDark"
		"Menu.ArmedBgColor"									"Gray"
		"Menu.TextInset"									"6"

		"Chat.TypingText"									"MainTheme"

		"Panel.FgColor"										"Gray"
		"Panel.BgColor"										"Blank"

		"HTML.BgColor"										"Blank"

		"ProgressBar.FgColor"								"White"
		"ProgressBar.BgColor"								"ProgressBackground"

		"CircularProgressBar.FgColor"						"White"
		"CircularProgressBar.BgColor"						"White"

		"BuildingHealthBar.BgColor"							"LightTransparentBlack"
		"BuildingHealthBar.Health"							"White"
		"BuildingHealthBar.LowHealth"						"Red"

		"PropertySheet.TextColor"							"MainTheme"
		"PropertySheet.SelectedTextColor"					"MainTheme"
		"PropertySheet.TransitionEffectTime"				"0.25"
		"RadioButton.TextColor"								"MainTheme"
		"RadioButton.SelectedTextColor"						"MainTheme"

		"RichText.TextColor"								"Gray"
		"RichText.BgColor"									"Blank"
		"RichText.SelectedTextColor"						"Gray"
		"RichText.SelectedBgColor"							"MainTheme"

		"ScrollBarButton.FgColor"							"TanDark"
		"ScrollBarButton.BgColor"							"Blank"
		"ScrollBarButton.ArmedFgColor"						"MainTheme"
		"ScrollBarButton.ArmedBgColor"						"Blank"
		"ScrollBarButton.DepressedFgColor"					"Black"
		"ScrollBarButton.DepressedBgColor"					"Blank"

		"ScrollBarSlider.FgColor"							"TanDark"
		"ScrollBarSlider.BgColor"							"Blank"

		"SectionedListPanel.HeaderTextColor"				"MainTheme"
		"SectionedListPanel.HeaderBgColor"					"Blank"
		"SectionedListPanel.DividerColor"					"Black"
		"SectionedListPanel.TextColor"						"MainTheme"
		"SectionedListPanel.BrightTextColor"				"MainTheme"
		"SectionedListPanel.BgColor"						"LightTransparentBlack"
		"SectionedListPanel.SelectedTextColor"				"Black"
		"SectionedListPanel.SelectedBgColor"				"Red"
		"SectionedListPanel.OutOfFocusSelectedTextColor"	"Black"
		"SectionedListPanel.OutOfFocusSelectedBgColor"		"255 255 255 32"

		"Slider.NobColor"									"White"
		"Slider.TextColor"									"White"
		"Slider.TrackColor"									"TanDaker"
		"Slider.DisabledTextColor1"							"TanDark"
		"Slider.DisabledTextColor2"							"TanDarker"

		"TextEntry.TextColor"								"White"
		"TextEntry.BgColor"									"Blank"
		"TextEntry.CursorColor"								"White"
		"TextEntry.DisabledTextColor"						"TanDark"
		"TextEntry.DisabledBgColor"							"Blank"
		"TextEntry.SelectedTextColor"						"White"
		"TextEntry.SelectedBgColor"							"MainTheme"
		"TextEntry.OutOfFocusSelectedBgColor"				"Blank"
		"TextEntry.FocusEdgeColor"							"Blank"

		"ToggleButton.SelectedTextColor"					"MainTheme"

		"Tooltip.TextColor"									"TransparentBlack"
		"Tooltip.BgColor"									"Red"

		"TreeView.BgColor"									"TransparentBlack"

		"WizardSubPanel.BgColor"							"Blank"

		"TimerProgress.Active"								"White"
		"TimerProgress.InActive"							"TanDark"
		"TimerProgress.Warning"								"Red"

		"HudObjectives.FgColor"								"TanDark"
		"HudObjectives.BgColor"								"TanDark"
		"HudObjectives.BorderColor"							"TanDark"

		"HudProgressBar.Active"								"White"
		"HudProgressBar.InActive"							"White"

		"HudCaptureIcon.Active"								"White"
		"HudCaptureIcon.InActive"							"White"
		"HudCaptureProgressBar.Active"						"White"
		"HudCaptureProgressBar.InActive"					"White"

		"FgColor"											"White"
		"BgColor"											"TransparentBlack"

		"ViewportBG"										"Blank"
		"TeamSpec"											"TanDark"
		"TeamRed"											"HUDRedTeamSolid"
		"TeamBlue"											"HUDBlueTeamSolid"

		"MapDescriptionText"								"White"
		"HudIcon_Green"										"GreenSolid"
		"HudIcon_Red"										"Red"

		"ItemColor"											"White"
		"MenuColor"											"White"
		"MenuBoxBg"											"TransparentBlack"

		"SelectionNumberFg"									"White"
		"SelectionTextFg"									"White"
		"SelectionEmptyBoxBg" 								"LightTransparentBlack"
		"SelectionBoxBg" 									"LightTransparentBlack"
		"SelectionSelectedBoxBg" 							"TransparentBlack"

		"HintMessageFg"										"White"
		"HintMessageBg" 									"LightTransparentBlack"

		"ProgressBarFg"										"Red"

		"MainTheme.Menu.X"									"32"
		"MainTheme.Menu.Y"									"248"

		"MainTheme.BottomBorder"							"32"

		"VguiScreenCursor"									"White"
	}
}