"Resource/UI/LayeredMapPanelToolTip.res"
{		
	
}
