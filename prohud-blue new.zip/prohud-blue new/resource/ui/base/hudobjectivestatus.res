"Resource/UI/HudObjectiveStatus.res"
{	}
