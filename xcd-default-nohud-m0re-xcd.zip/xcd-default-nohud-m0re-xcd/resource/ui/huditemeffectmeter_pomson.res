#base "huditemeffectmeter.res"
