"Resource/UI/LayeredMapPanelToolTip.res"
{		
	
}
