"Resource/UI/HudDamageAccount.res"
{
}