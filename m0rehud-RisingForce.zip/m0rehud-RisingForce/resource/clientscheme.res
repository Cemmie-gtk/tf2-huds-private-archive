//=========================================================
// COLORS SCHEME
//=========================================================

#base "../resource/scheme/colors.res"

//=========================================================
// FONTS SCHEME
//=========================================================

#base "../resource/scheme/fonts.res"

//=========================================================
// CROSSHAIRS SCHEME
//=========================================================

#base "../scripts/crosshairs/font/crosshairs.res"

//=========================================================
// DEFAULT TF2 SCHEME
//=========================================================

#base "../resource/scheme/default.res"
"#base"		"clientscheme_Sayo-toemas.res"

"#base"		"clientscheme_Sayo-zhern.res"
