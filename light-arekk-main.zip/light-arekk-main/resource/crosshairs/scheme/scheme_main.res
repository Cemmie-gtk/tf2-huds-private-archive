Scheme
{
	Fonts
	{
		"Size:10 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"10"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:11 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"11"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:12 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"12"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:13 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"13"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:14 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"14"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:15 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"15"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:16 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"16"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:17 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"17"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:18 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"18"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:19 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"19"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:20 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"20"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:21 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"21"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:22 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"22"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:23 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"23"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:24 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"24"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:25 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"25"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:26 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"26"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:27 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"27"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:28 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"28"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:29 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"29"
				"weight"		"0"
				"antialias"		"1"
			}
		}
		"Size:30 | Outline:OFF"
		{
			"1"
			{
				"name"			"TF2Crosshairs"
				"tall"			"30"
				"weight"		"0"
				"antialias"		"1"
			}
		}
	}
	
	CustomFontFiles
	{
		"100"
		{
			"font" "resource/crosshairs/TF2Crosshairs.ttf"
			"font" "resource/crosshairs/tf2crosshairs_linux.ttf" [$LINUX]
			"name" "TF2Crosshairs"
		}
	}
}