"Resource/UI/HudDamageAccount.res"
{
}