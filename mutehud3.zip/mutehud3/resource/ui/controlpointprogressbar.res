"Resource/UI/ControlPointProgressBar.res"
{
	"ControlPointProgressBar"
	{
		"ControlName"	"EditablePanel"
		"fieldName"	"ControlPointProgressBar"
		"xpos"		"0"
		"ypos"		"0"
		"zpos"		"20"
		"wide"		"100"
		"wide_minmode"		"65"
		"tall"		"65"
		"tall_minmode"		"42"
		"visible"	"0"
		"enabled"	"1"
	}

	"ProgressBar"
	{
		"ControlName"	"CircularProgressBar"
		"fieldName"	"ProgressBar"
		"xpos"		"28"
		"xpos_minmode"		"18"
		"ypos"		"5"
		"ypos_minmode"		"3"
		"zpos"		"23"
		"wide"		"0"         //45
		"wide_minmode"		"0" //29
		"tall"		"0"         //45   
		"tall_minmode"		"0" //29
		"autoResize"	"0"
		"pinCorner"	"0"
		"visible"	"0"          //1
		"enabled"	"0"          //1
		"fg_image"	"progress_bar_blu"
		"bg_image"	"progress_bar_blu"
	}

	"Teardrop"
	{
		"ControlName"	"CIconPanel"
		"fieldName"	"Teardrop"
		"xpos"		"24"
		"xpos_minmode"		"16"
		"ypos"		"0"
		"ypos_minmode"		"0"
		"zpos"		"21"
		"wide"		"0"
		"wide_minmode"		"0"
		"tall"		"0"
		"tall_minmode"		"0"
		"visible"	"0"
		"enabled"	"0"
		"scaleImage"	"0"
		"icon"		"cappoint_progressbar_teardrop"
		"iconColor"	"255 255 255 255"
	}
	
	"TeardropSide"
	{
		"ControlName"	"CIconPanel"
		"fieldName"	"TeardropSide"
		"xpos"		"24"
		"xpos_minmode"		"15"
		"ypos"		"0"
		"ypos_minmode"		"0"
		"zpos"		"0"
		"wide"		"0"
		"wide_minmode"		"0"
		"tall"		"0"
		"tall_minmode"		"0"
		"visible"	"0"
		"enabled"	"0"
		"scaleImage"	"0"
		"icon"		"cappoint_progressbar_teardrop"
		"iconColor"	"255 255 255 255"
	}

	"ProgressText"
	{	
		"ControlName"		"Label"
		"fieldName"		"ProgressText"
		"font"			"DefaultSmall"
		"font_minmode"			"DefaultVerySmall"
		"xpos"			"14"
		"xpos_minmode"			"10"
		"ypos"			        "8" // 8
		"ypos_minmode"			"12" // 0
		"zpos"			"23"
		"wide"			"75"
		"wide_minmode"			"49"
		"tall"			"40"
		"tall_minmode"			"36"
		"autoResize"		"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"labelText"		"progress"
		"dulltext"		"0"
		"brighttext"		"0"
		"centerwrap"	"1"
	}

	"Blocked"
	{
		"ControlName"	"CIconPanel"
		"fieldName"	"Blocked"
		"xpos"		"26"
		"xpos_minmode"		"18"
		"ypos"		"3"
		"ypos_minmode"		"2"
		"zpos"		"21"
		"wide"		"0"
		"wide_minmode"		"0"
		"tall"		"0"
		"tall_minmode"		"0"
		"visible"	"0"
		"enabled"	"0"
		"scaleImage"	"0"
		"icon"		"cappoint_progressbar_blocked"
		"iconColor"	"255 255 255 255"
	}
}
