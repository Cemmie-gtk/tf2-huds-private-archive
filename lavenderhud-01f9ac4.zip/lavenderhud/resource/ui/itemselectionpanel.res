"Resource/UI/ItemSelectionPanel.res"
{
	"ItemSelectionPanel"
	{
		"ControlName"	"EditablePanel"
		"fieldName"		"ItemSelectionPanel"
		"xpos"			"0"
		"ypos"			"0"
		"zpos"			"500"
		"wide"			"f0"
		"tall"			"480"
		"visible"		"1"

		"settitlebarvisible"	"0"
		"bgcolor_override"		"gravy_darkest"
		
		"item_ypos"		"60"
		"item_ydelta"	"80"
		"item_backpack_offcenter_x"		"-288"
		"item_backpack_xdelta"			"4"
		"item_backpack_ydelta"			"3"

		"modelpanels_selection_kv"
		{
			"wide"				"94"
			"tall"				"70"
			"model_xpos"		"2"
			"model_wide"		"75"
			"model_tall"		"50"
			"model_center_x"	"1"
			"text_ypos"			"0"
			"text_forcesize"	"2"
			"text_center"		"0"
			"text_yoffset"		"2"
			"inset_eq_y"		"55"
			"inset_eq_x"		"55"

			"deferred_description"	"1"
			"deferred_icon"			"1"
		}
		"modelpanels_kv"
		{
			"ControlName"	"CItemModelPanel"
			"xpos"			"c-70"
			"ypos"			"270"
			"wide"			"54"
			"tall"			"42"
			"visible"		"0"
			"bgcolor_override"		"0 0 0 0"
			"noitem_textcolor"		"117 107 94 255"
			"PaintBackgroundType"	"2"
			"paintborder"	"1"
			
			"model_xpos"	"2"
			"model_ypos"	"5" 
			"model_wide"	"50"
			"model_tall"	"35"
			"text_ypos"		"60"
			"text_center"	"1"
			"name_only"		"1"
			
			"inset_eq_x"	"4"
			"inset_eq_y"	"2"

			"deferred_description"	"1"
			
			"itemmodelpanel"
			{
				"inventory_image_type"	"1" // only 0-1, 1 looks best
				"use_item_rendertarget" "0"
				"allow_rot"				"0"
			}
			
			"use_item_sounds"	"1"
		}
		"duplicatelabels_kv"
		{
			"font"			"ItemFontNameSmallest"
			"textAlignment"	"center"
			"wide"			"20"
			"tall"			"15"
			"zpos"			"1"

			"fgcolor"		"153 204 255 255"
		}
	}
	
	"CaratLabel"
	{
		"ControlName"		"CExLabel"
		"fieldName"			"CaratLabel"
		"fgcolor_override" 	"gravy_primary"
		"font"				"icon30"
		"labelText"			"v"
		"textAlignment"		"east"
		"xpos"				"25"
		"ypos"				"-5"
		"zpos"				"1"
		"wide"				"20"
		"tall"				"35"
		"visible"			"1"
		"pin_to_sibling"	"ClassLabel"
	}

	"ClassLabel"
	{
		"ControlName"			"CExLabel"
		"fieldName"				"ClassLabel"
		"fgcolor_override"		"gravy_primary"
		"font"					"star35"
		"labelText"				"#ClassBeingEquipped"
		"textAlignment"			"east"
		"auto_wide_tocontents"	"1"
		"pinCorner"				"PIN_CENTER_RIGHT"
		"xpos"					"c240"
		"ypos"					"15"
		"zpos"					"1"
		"wide"					"240"
		"tall"					"35"
		"visible"				"1"
		
	}

	"NameFilterLabel" //searchbar title
	{
		"ControlName"	"CExLabel"
		"fieldName"		"NameFilterLabel"
		"font"			"milku15"
		"labelText"		"#Store_NameFilterLabel"
		"textAlignment"	"west"
		"xpos"			"c-285"
		"ypos"			"14"
		"zpos"			"1"
		"wide"			"90"
		"tall"			"20"
		"autoResize"	"1"

		"visible"		"1"
		"fgcolor"		"gravy_offwhite"
	}

	"NameFilterTextEntry"
	{
		"ControlName"			"TextEntry"
		"fieldName"				"NameFilterTextEntry"
		"xpos"					"c-287"
		"ypos"					"30"
		"zpos"					"1"
		"wide"					"128"
		"tall"					"16"
		"visible"				"1"
		"tabPosition"			"1"
		"textHidden"			"0"
		"editable"				"1"
		"unicode"				"1"
		"fgcolor_override"		"gravy_offwhite"
		"bgcolor_override"		"0 0 0 0"
		"paintBackground"		"1"
		"paintBorder"			"1"
		"border"				"rounded_dark_24x"
		"font"					"milku10"
	}
	"SearchbarBG"
	{
		"ControlName"			"Panel"
		"fieldName"				"SearchbarBG"
		"xpos"					"0"
		"ypos"					"0"
		"wide"					"128"
		"tall"					"16"
		"border"				"rounded_dark_16x"

		"pin_to_sibling"		"NameFilterTextEntry"
	}
	
	"TopLine"
	{
		"ControlName"	"ImagePanel"
		"fieldName"		"TopLine"
		"xpos"			"cs-0.5"
		"ypos"			"50"
		"zpos"			"2"
		"wide"			"586"
		"tall"			"10"
		"visible"		"1"

		"image"			"replay/thumbnails/misc/line_dashed_16x"
		"tileImage"		"1"
		"tileVertically" "0"

		"fillcolor"		"blank"
		"drawcolor"		"gravy_primary"
	}				
	"BottomLine"
	{
		"ControlName"	"ImagePanel"
		"fieldName"		"BottomLine"
		"xpos"			"c-305"
		"ypos"			"330"
		"zpos"			"2"
		"wide"			"610"
		"tall"			"10"
		"visible"		"0"

		"image"			"loadout_dotted_line"
		"tileImage"		"1"
		"tileVertically" "0"
	}				
		
	"ItemSlotLabel"
	{
		"ControlName"		"CExLabel"
		"fieldName"			"ItemSlotLabel"
		"font"				"milku20"
		"labelText"			"#PrimaryWeapon"
		"textAlignment"		"center"
		"xpos"				"cs-0.5"
		"ypos"				"27"
		"zpos"				"1"
		"wide"				"375"
		"tall"				"25"

		"visible"			"1"

	}

	"NoItemsLabel"
	{
		"ControlName"	"CExLabel"
		"fieldName"		"NoItemsLabel"
		"font"			"HudFontSmallBold"
		"labelText"		"#NoItemsToEquip"
		"textAlignment"	"center"
		"xpos"			"c-300"
		"ypos"			"120"
		"zpos"			"10"
		"wide"			"600"
		"tall"			"30"


		"visible"		"0"

		"fgcolor_override" "200 80 60 255"
	}
	
	"CancelButton"
	{
		"ControlName"	"CExButton"
		"fieldName"		"CancelButton"
		"xpos"			"c-200"
		"ypos"			"400"
		"zpos"			"2"
		"wide"			"200"
		"tall"			"25"

		"pinCorner"		"2"
		"visible"		"0"


		"labelText"		"#Cancel"
		"font"			"HudFontSmallBold"
		"textAlignment"	"center"


		"Command"		"vguicancel"
		"sound_depressed"	"UI/buttonclick.wav"

	}
	
	"OnlyAllowUniqueQuality"
	{
		"ControlName"	"CheckButton"
		"fieldName"		"OnlyAllowUniqueQuality"
		"labelText"		"#OnlyAllowUniqueQuality"
		"Font"			"HudFontSmallestBold"
		"textAlignment"	"east"
		"xpos"			"c-306"
		"ypos"			"340"
		"zpos"			"1"
		"wide"			"290"
		"tall"			"25"

		"visible"		"0"
	}	
	
	"ShowBackpack"
	{
		"ControlName"	"CExButton"
		"fieldName"		"ShowBackpack"
		"xpos"			"9999"
		"ypos"			"340"
		"zpos"			"20"
		"wide"			"200"
		"tall"			"25"
		"visible"		"0"

		"labelText"		"#Selection_ShowBackpack"
		"font"			"HudFontSmallBold"
		"textAlignment"	"center"
		"textinsetx"	"50"


		"Command"			"show_backpack"
		"sound_depressed"	"UI/buttonclick.wav"

	}
	"ShowSelection"
	{
		"ControlName"	"CExButton"
		"fieldName"		"ShowSelection"
		"xpos"			"c100"
		"ypos"			"340"
		"zpos"			"20"
		"wide"			"200"
		"tall"			"25"


		"visible"		"1"


		"labelText"		"#Selection_ShowSelection"
		"font"			"HudFontSmallBold"
		"textAlignment"	"center"
		"textinsetx"	"50"


		"Command"			"show_selection"
		"sound_depressed"	"UI/buttonclick.wav"

	}
	
	"PrevPageButton"
	{
		"ControlName"		"CExButton"
		"fieldName"			"PrevPageButton"
		"xpos"				"c195"
		"ypos"				"340"
		"zpos"				"1"
		"wide"				"24"
		"tall"				"24"
		"visible"			"1"
		
		"labelText"			"µ"
		"font"				"icon20"
		"textAlignment"		"center"
		"Command"			"prevpage"
		"paintbackground"	"0"

		"defaultfgcolor_override"	"gravy_darkest"
		"armedFgColor_override"		"gravy_darkest"
		"depressedFgColor_override"	"gravy_darkest"
		
		"border_default"	"rounded_dark_24x"
		"border_armed"		"rounded_primary_24x"
		"border_depressed" 	"rounded_primary_dark_24x"
		
		"sound_depressed"	"UI/buttonclick.wav"
		"sound_armed"		"UI/buttonrollover.wav"
	}	
	"PrevPagehotkey"
	{
		"ControlName"		"CExButton"
		"fieldName"			"PrevPagehotkey"
		"xpos"				"9999"
		"ypos"				"0"
		"zpos"				"1"
		"wide"				"32"
		"tall"				"32"
		"visible"			"1"
		
		"labelText"			"&A"
		"Command"			"prevpage"
	}	
	"CurPageLabel"
	{
		"ControlName"		"CExLabel"
		"fieldName"			"CurPageLabel"
		"font"				"jua15"
		"labelText"			"%backpackpage%"
		"textAlignment"		"center"
		"xpos"				"c220"
		"ypos"				"340"
		"zpos"				"1"
		"wide"				"40"
		"tall"				"24"
		"autoResize"		"1"

		"visible"			"1"

		"fgcolor_override" 	"gravy_offwhite"
	}
	"NextPageButton"
	{
		"ControlName"		"CExButton"
		"fieldName"			"NextPageButton"
		"xpos"				"c265"
		"ypos"				"340"
		"zpos"				"1"
		"wide"				"24"
		"tall"				"24"
		
		"visible"			"1"

		"labelText"			"¶"
		"font"				"icon20"
		"textAlignment"		"center"
		"Command"			"nextpage"
		"paintbackground"	"0"

		"defaultfgcolor_override"	"gravy_darkest"
		"armedFgColor_override"		"gravy_darkest"
		"depressedFgColor_override"	"gravy_darkest"
		
		"border_default"	"rounded_dark_24x"
		"border_armed"		"rounded_primary_24x"
		"border_depressed" 	"rounded_primary_dark_24x"
		
		"sound_depressed"	"UI/buttonclick.wav"
		"sound_armed"		"UI/buttonrollover.wav"
	}		
	"NextPagehotkey"
	{
		"ControlName"	"CExButton"
		"fieldName"		"NextPagehotkey"
		"xpos"			"9999"
		"ypos"			"0"
		"zpos"			"1"
		"wide"			"20"
		"tall"			"20"
		"visible"		"1"

		
		"labelText"			"&D"
		"textAlignment"		"center"
		"Command"			"nextpage"
		"paintbackground"	"0"
		"mouseinputenabled"	"0"
	}		
	
	"mouseoveritempanel"
	{
		"ControlName"	"CItemModelPanel"
		"fieldName"		"mouseoveritempanel"
		"xpos"			"c-70"
		"ypos"			"270"
		"zpos"			"100"
		"wide"			"300"
		"tall"			"300"
		"visible"		"0"
		"bgcolor_override"		"0 0 0 0"
		"noitem_textcolor"		"117 107 94 255"
		"PaintBackgroundType"	"2"
		"paintborder"	"1"
		
		"text_ypos"			"20"
		"text_center"		"1"
		"model_hide"		"1"
		"resize_to_text"	"1"
		"padding_height"	"15"
		
		"attriblabel"
		{
			"font"			"ItemFontAttribLarge"
			"xpos"			"0"
			"ypos"			"30"
			"zpos"			"2"
			"wide"			"140"
			"tall"			"60"


			"visible"		"1"

			"labelText"		"%attriblist%"
			"textAlignment"	"center"
			"fgcolor"		"117 107 94 255"
			"centerwrap"	"1"
		}
	}
}
