"Resource/UI/HudTeamSwitch.res"
{
	"HudTeamSwitchBG"
	{
		"ControlName"		"CTFImagePanel"
		"fieldName"		"HudTeamSwitchBG"
		"xpos"			"0"
		"ypos"			"0"
		"zpos"			"-1"
		"wide"			"320"
		"tall"			"150"


		"visible"		"1"

		"image"			"../hud/death_panel_blue_bg"
		"scaleImage"		"1"
		"teambg_2"		"../hud/death_panel_red_bg"
		"teambg_3"		"../hud/death_panel_blue_bg"
	}
	"SwitchLabel"
	{	
		"ControlName"		"Label"
		"fieldName"		"SwitchLabel"
		"font"			"TFFontMedium"
		"xpos"			"80"
		"ypos"			"58"


		"zpos"			"1"
		"wide"			"240"
		"tall"			"55"


		"visible"		"1"

		"wrap"			"1"
		"labelText"		"#TF_teambalanced"
		"textAlignment"		"North"
	}
	"BalanceLabel"
	{	
		"ControlName"		"Label"
		"fieldName"		"BalanceLabel"
		"font"			"HudFontSmallBold"
		"xpos"			"80"
		"ypos"			"28"


		"zpos"			"1"
		"wide"			"230"	[$WIN32]

		"tall"			"55"


		"visible"		"1"

		"wrap"			"1"
		"labelText"		""
		"textAlignment"		"North"
	}
	"SwitchImage"
	{
		"ControlName"		"CTFImagePanel"
		"fieldName"		"SwitchImage"
		"xpos"			"25"
		"ypos"			"23"
		"zpos"			"1"
		"wide"			"50"
		"tall"			"50"


		"visible"		"1"

		"image"			"../hud/ico_teambalance"
		"scaleImage"		"1"
	}
}
