"Resource/UI/HudObjectiveStatus.res"
{	}
