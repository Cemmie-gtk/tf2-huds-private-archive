"Resource/UI/LeaderboardEntry.res"
{
}