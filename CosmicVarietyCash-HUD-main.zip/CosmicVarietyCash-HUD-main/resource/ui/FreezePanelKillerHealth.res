"Resource/UI/FreezePanelKillerHealth.res"
{
	"PlayerStatusHealthValue"
	{
		"ControlName"								"Label"
		"fieldName"									"PlayerStatusHealthValue"
		"xpos"										"0"
		"ypos"										"5"
		"zpos"										"20"
		"wide"										"40"
		"tall"										"20"
		"visible"									"1"
		"enabled"									"1"
		"textAlignment"								"center"	
		"labeltext"									"%Health%"
		"font"										"M0refont24"
		"fgcolor_override"  						"Health Numbers"	
	}
	
	"PlayerStatusHealthValueShadowKiller"
	{
		"ControlName"								"Label"
		"fieldName"									"PlayerStatusHealthValueShadowKiller"
		"xpos"										"1"
		"ypos"										"6"
		"zpos"										"20"
		"wide"										"40"
		"tall"										"20"
		"visible"									"1"
		"enabled"									"1"
		"textAlignment"								"center"	
		"labeltext"									"%Health%"
		"font"										"M0refont24"
		"fgcolor_override"  						"0 0 0 255"	
	}
	
	"PlayerStatusHealthBonusImage"
	{
		"ControlName"								"ImagePanel"
		"fieldName"									"PlayerStatusHealthBonusImage"
		"xpos"										"10"
		"ypos"										"6"
		"zpos"										"19"
		"wide"										"21"
		"tall"										"21"
		"visible"									"0"
		"enabled"									"1"
		"image"										"../hud/health_over_bg"
		"scaleImage"								"1"	
	}
	
	
	
	
	
	//////////////////////////////////REMOVED STUFF//////////////////////////////////
	
	"PlayerStatusHealthImage"
	{
		"ControlName"								"ImagePanel"
		"fieldName"									"PlayerStatusHealthImage"
		"wide"										"0"
		"tall"										"0"
		"visible"									"0"
		"enabled"									"0"	
	}
	"PlayerStatusHealthImageBG"
	{
		"ControlName"								"ImagePanel"
		"fieldName"									"PlayerStatusHealthImageBG"
		"wide"										"0"
		"tall"										"0"
		"visible"									"0"
		"enabled"									"0"	
	}
	"BuildingStatusHealthImageBG"
	{
		"ControlName"								"ImagePanel"
		"fieldName"									"PlayerStatusHealthImageBG"
		"wide"										"0"
		"tall"										"0"
		"visible"									"0"
		"enabled"									"0"	
	}
}