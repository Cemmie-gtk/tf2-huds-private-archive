"Resource/UI/NotificationToastContainer.res"
{
	"NotificationToastContainer"
	{
		"ControlName"	"CNotificationToastControl"
		"fieldName"		"NotificationToastContainer"
		"xpos"			"0"
		"ypos"			"0"
		"zpos"			"1"
		"wide"			"150"
		"tall"			"50"
		"visible"		"1"
		"enabled"		"1"
		"border"		"TFFatLineBorderOpaque"
	}
	
	"NotificationBGshade"
	{
		"ControlName"	"ImagePanel"
		"fieldName"		"NotificationBGshade"
		"xpos"			"0"
		"ypos"			"0"
		"wide"			"f0"
		"tall"			"f0"
		"zpos"			"-10"
		"autoResize"	"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"fillcolor"		"22 22 22 255"
		"PaintBackgroundType""0"
	}


	"HelpTextLabel"
	{	
		"ControlName"	"CExLabel"
		"fieldName"		"HelpTextLabel"
		"fgcolor"		"RedSolid"
		"xpos"			"5"
		"ypos"			"0"
		"zpos"			"2"
		"wide"			"140"
		"tall"			"38"
		"autoResize"	"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"wrap"			"1"
		"labelText"		""
		"textAlignment"	"North"
		"font"			"TFFontSmall"
		"textinsetx"	"2"
		"textinsety"	"7"
	}

}
