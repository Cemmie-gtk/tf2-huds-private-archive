Scheme
{
	Fonts
	{
		
		"nü44"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"44"
				"antialias" "1"
			}
		}
		"nü24"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"24"
				"antialias" "1"
			}
		}
		"nü20"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"20"
				"antialias" "1"
			}
		}
		"nü12"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"12"
				"antialias" "1"
			}
		}
		"nü10"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"10"
				"antialias" "1"
			}
		}
		"nüBold16"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"16"
				"antialias" "1"
			}
		}
		"nüBoldShadow16"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"16"
				"antialias" "1"
				"blur"		"1"
			}
		}
		"nüShadow16"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"16"
				"antialias" "1"
				"blur"		"1"
			}
		}
		"nüMedium16"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"16"
				"antialias" "1"
			}
		}
		"nüMediumShadow16"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"16"
				"antialias" "1"
				"blur"		"1"
			}
		}
		"nüMedium14"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"14"
				"antialias" "1"
			}
		}
		"nüShadow14"
		{
			"1"
			{
				"name"		"Rubik SemiBold"
				"tall"		"14"
				"antialias" "1"
				"blur"		"1"
			}
		}
		"menubig"
		{
			"1"
			{
				"name"										"Harabara Bold"
				"tall"										"20"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"menu"
		{
			"1"
			{
				"name"										"Harabara Bold"
				"tall"										"10"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"classselect"
			{
			"1"
			{
				"name"										"Harabara Bold"
				"tall"										"11"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"hpammoalt"
		{
			"1"
			{
				"name"		"Surface-Medium"
				"tall"		"72"
				"weight"	"500"
				"additive"	"0"
				"antialias" "1"
			}
		}
		"hpammo"
		{
			"1"
			{
				"name"		"TF2 Build"
				"tall"		"40"
				"weight"	"500"
				"additive"	"0"
				"antialias" "1"
			}
		}
		"hpammosmall"
		{
			"1"
			{
				"name"		"TF2 Build"
				"tall"		"17"
				"tall_lodef"	"40"
				"weight"	"500"
				"additive"	"0"
				"antialias" "1"
			}
		}
		"hpammosmallalt"
		{
			"1"
			{
				"name"		"Surface-Medium"
				"tall"		"24"
				"weight"	"500"
				"additive"	"0"
				"antialias" "1"
			}
		}
		"lastdmg"
		{
			"1"
			{
				"name"										"verdana"
				"tall"										"15"
				"additive"									"0"
				"antialias" 								"1"
				"outline" 									"0"
			}
		}
		"dmg"
		{
			"1"
			{
				"name"										"Verdana"
				"tall"										"20"
				"additive"									"0"
				"antialias" 								"1"
				"outline" 									"1"
			}
		}
		"sticks"
		{
			"1"
			{
				"name"		"TF2 Build"
				"tall"		"15"
				"weight"	"500"
				"additive"	"0"
				"antialias" "1"
			}
		}
		"m0refont10"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"10"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont11"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"11"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont12"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"12"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont12Shadow"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"12"
				"additive"									"0"
				"antialias" 								"1"
				"dropshadow" 								"1"
			}
		}
		"m0refont14"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"14"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont16"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"16"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont18"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"18"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont18Shadow"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"18"
				"additive"									"0"
				"antialias" 								"1"
				"dropshadow" 								"1"
			}
		}
		"m0refont18Outline"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"18"
				"additive"									"0"
				"antialias" 								"1"
				"outline" 									"1"
			}
		}
		"m0refont18Numbers"
		{
			"1"
			{
				"name"										"Surface-Numbers"
				"tall"										"18"
				"additive"									"0"
				"antialias" 								"1"
				"outline" 									"1"
			}
		}
		"m0refont20"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"20"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont24"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"24"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont24Shadow"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"24"
				"additive"									"0"
				"antialias" 								"1"
				"dropshadow" 								"1"
			}
		}
		"m0refont24Outline"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"24"
				"additive"									"0"
				"antialias" 								"1"
				"outline" 									"1"
			}
		}
		"m0refont24Numbers"
		{
			"1"
			{
				"name"										"Surface-Numbers"
				"tall"										"24"
				"additive"									"0"
				"antialias" 								"1"
				"outline" 									"1"
			}
		}
		"m0refont26"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"26"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont30"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"30"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont30Outline"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"30"
				"additive"									"0"
				"antialias" 								"1"
				"outline" 									"1"
			}
		}
		"m0refont30Numbers"
		{
			"1"
			{
				"name"										"Surface-Numbers"
				"tall"										"30"
				"additive"									"0"
				"antialias" 								"1"
				"outline" 									"1"
			}
		}
		"m0refont32"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"32"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont32Shadow"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"32"
				"additive"									"0"
				"antialias" 								"1"
				"dropshadow" 								"1"
			}
		}
		"m0refont36"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"36"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont48"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"48"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"m0refont72"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"72"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		
		"m0reSymbols"
		{
			"1"
			{
				"name"										"m0re Icons"
				"tall"										"14"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		
		"Coolvetica11"
		{
			"1"
			{
				"name"										"Coolvetica"
				"tall"										"11"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"Coolvetica13"
		{
			"1"
			{
				"name"										"Coolvetica"
				"tall"										"13"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		"Coolvetica15"
		{
			"1"
			{
				"name"										"Coolvetica"
				"tall"										"15"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		
		"VerdanaMenu"										//Only Used For Create Server Button
		{
			"1"
			{
				"name"										"Verdana"
				"tall"										"18"
				"additive"									"0"
				"antialias" 								"1"
			}
		}
		
		"BlocksSharp64"
		{
			"1"
			{
				"name"										"Blocks"
				"tall"										"64"
				"additive"									"0"
				"antialias" 								"0"
			}
		}
		
		"Default"
		{
			"1"
			{
				"name"		  								"Surface-Medium"
				"tall"      								"14"
				"weight"									"0"
				"antialias" 								"1"
			}
			"2"
			{
				"name"		 								"Surface-Medium"
				"tall"      								"18"
				"weight"									"0"
				"antialias" 								"1"
			}
			"3"
			{
				"name"		  								"Surface-Medium"
				"tall"      								"22"
				"weight"									"0"
				"antialias" 								"1"
			}
			"4"
			{
				"name"		  								"Surface-Medium"
				"tall"      								"24"
				"weight"									"0"
				"antialias" 								"1"
			}
			"5"
			{
				"name"										"Surface-Medium"
				"tall"										"24"
				"weight"									"0"
				"antialias"									"1"
			}
		}
		
		"CloseCaption_Normal"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"24"
				"weight"									"0"
				"antialias" 								"1"
			}
		}
		"CloseCaption_Italic"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"24"
				"weight"									"0"
				"italic"									"0"
				"antialias" 								"1"
			}
		}
		"CloseCaption_Bold"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"24"
				"weight"									"0"
				"antialias" 								"1"
			}
		}
		"CloseCaption_BoldItalic"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"24"
				"weight"									"0"
				"italic"									"0"
				"antialias" 								"1"
			}
		}
		"CloseCaption_Small"
		{
			"1"
			{
				"name"										"Surface-Medium"
				"tall"										"16"
				"weight"									"0"
				"antialias" 								"1"
			}
		}
	}
	
	CustomFontFiles
	{
		"8" 
		{
			"font" 		"resource/fonts/Surface_Medium.otf"
			"name" 		"Surface-Medium"
		}
		
		"9" 
		{
			"font" 		"resource/fonts/COOLVETI.TTF"
			"name" 		"Coolvetica"
		}
		
		"10" 
		{
			"font" 		"resource/fonts/Blocks.ttf"
			"name" 		"Blocks"
		}
		
		"12" 
		{
			"font" 		"resource/fonts/m0re Icons.otf"
			"name" 		"m0re Icons"
		}
		
		"11" 
		{
			"font" 		"resource/fonts/Surface_Numbers.otf"
			"name" 		"Surface-Numbers"
		}
		"13"
		{
			"font" 		"resource/fonts/Harabara.ttf"
			"name" 		"Harabara Bold"
		}
		"14"
		{
			"font" 		"resource/fonts/Verdana.ttf"
			"name" 		"Verdana"
		}
		"15"
		{
			"font" 		"resource/fonts/rubik-semibold.otf"
			"name" 		"Rubik SemiBold"
		}
	}
}