"Resource/UI/HudDamageAccount.res"
{
	
}