#base "huditemeffectmeter.res"
