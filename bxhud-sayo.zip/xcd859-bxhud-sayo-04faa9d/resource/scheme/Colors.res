Scheme
{
	Colors
	{
	
		//=============================================================================
		// INGAME COLORS
		//=============================================================================		
	
		"main"												"129 209 244 255"
	
		"BuffedColor1"										"255 255 255 255"
		"BuffedColor2"										"0 0 0 255"	
		
		"LowColor1"											"177 0 0 255"	
		"LowColor2"											"255 255 255 255"			
		
		"HealthPickupColor"									"129 209 244 255"
		
		"FullUberColor1"									"0 0 0 255"	
		"FullUberColor2"									"255 255 255 255"	
		
		//=============================================================================
		// DEFAULT TF2 COLORS
		//=============================================================================
		
		"Orange"											"80 190 233 225"
		"OrangeDim"											"80 190 233 225"
		"LightOrange"										"80 190 233 225"
		"GoalOrange"										"255 133 0"
		"TFOrange"											"80 190 233 225"
		"Purple"											"137 69 99 255"

		"QuestGold"											"208 147 75 255"
		"HalloweenThemeColor2015_Light"						"238 126 17 255"
		"HalloweenThemeColor2015"							"135 54 16 255"
		"HalloweenThemeColor2015_Dark"						"108 49 21 255"
		"QuestUncommitted"									"183 147 100 255"

		"QuestMap_Bonus"									"222 217 166 255"
		"QuestMap_ActiveOrange"								"212 127 25 255"
		"QuestMap_InactiveGrey"								"100 100 100 255"
		"QuestMap_BGImages"									"56 58 60 255"

		"PartyMember1"										"124 173 255 255"
		"PartyMember2"										"99 232 167 255"
		"PartyMember3"										"229 255 121 255"
		"PartyMember4"										"232 184 99  255"
		"PartyMember5"										"255 118 108 255"
		"PartyMember6"										"255 133 255 255"

		"White"												"255 255 255 255"
		"Red"												"255 0 0 255"
		"RedSolid"											"192 28 0 255"
		"Blue"												"0 160 255 255"
		"Yellow"											"255 255 255 255"
		"TransparentYellow"									"255 255 255 255"
		"BrightYellow"										"235 235 52 255"
		"GreenSolid"		 								"76 107 34 255"

		"Black"												"0 0 0 255"
		"TransparentBlack"									"0 0 0 200"
		"TransparentLightBlack"								"0 0 0 100"
		"FooterBGBlack"										"52 48 55 255"

		"HUDBlueTeam"										"0 120 201 255"
		"HUDRedTeam"										"235 58 58 255"
		"HUDSpectator"										"120 115 105 255"
		"HUDBlueTeamSolid"									"115 150 170 255"
		"HUDRedTeamSolid"									"189 59 61 255"
		"HUDDeathWarning"									"255 0 0 255"
		"HudWhite"											"255 255 255 255"
		"HudOffWhite"										"255 255 255 255"
		"HudBlack"											"65 65 65 255"
		"ProgressBarBlue"									"91 122 142 255"

		"CreditsGreen"										"94 150 49 255"

		"Gray"												"178 178 178 255"

		"Blank"												"0 0 0 0"

		"HudPanelForeground"								"123 110 59 184"
		"HudPanelBackground"								"123 110 59 184"
		"HudPanelBorder"									"255 255 255 102"

		"HudProgressBarActive"								"255 255 255 255"
		"HudProgressBarInActive"							"255 255 255 255"
		"HudProgressBarActiveLow"							"255 25 25 255"
		"HudProgressBarInActiveLow"							"255 25 25 255"

		"HudTimerProgressActive"							"255 255 255 255"
		"HudTimerProgressInActive"							"52 48 45 255"
		"HudTimerProgressWarning"							"240 30 30 255"

		"HudTrainingHint"									"212 160 23 255"

		"TanDark"											"120 115 105 255"
		"TanLight"											"255 255 255 255"
		"TanDarker"											"45 40 35 255"

		"StoreDarkTan"										"131 121 104 255"
		"StoreGreen"										"76 107 34 255"

		"LowHealthRed"										"255 0 0 255"
		"ProgressOffWhite"									"255 255 255 255"
		"ProgressBackground"								"0 0 0 100"
		"HealthBgGrey"										"72 71 69 255"

		"ProgressOffWhiteTransparent"						"255 255 255 128"

		"LabelDark"											"0 0 0 255"
		"LabelTransparent"									"0 0 0 100"

		"BuildMenuActive"									"255 255 255 255"

		"DisguiseMenuIconRed"								"189 59 61 255"
		"DisguiseMenuIconBlue"								"115 150 170 255"

 		"MatchmakingDialogTitleColor"						"200 184 151 255"
 		"MatchmakingMenuItemBackground"						"46 43 42 255"
 		"MatchmakingMenuItemBackgroundActive"				"150 71 0 255"
		"MatchmakingMenuItemTitleColor"						"200 184 151 255"
		"MatchmakingMenuItemDescriptionColor"				"200 184 151 255"

		"HTMLBackground"									"95 92 101 255"

		"ItemAttribLevel"									"255 255 255 255"
		"ItemAttribNeutral"									"255 255 255 255"
		"ItemAttribPositive"								"255 255 255 255"
		"ItemAttribNegative"								"255 60 60 255"

		"ItemSetName"										"225 255 15 255"
		"ItemSetItemEquipped"								"149 175 12 255"
		"ItemSetItemMissing"								"139 137 137 255"
		"ItemIsotope"										"225 255 15 255"
		"ItemBundleItem"									"149 175 12 255"
		"ItemLimitedUse"									"0 160 0 255"
		"ItemFlags"											"255 255 255 255"
		"ItemLimitedQuantity"								"225 209 0 255"

		"QualityColorNormal"								"178 178 178 255"
		"QualityColorrarity1"								"77 116 85 255"
		"QualityColorrarity2"								"141 131 75 255"
		"QualityColorrarity3"								"204 204 250 255"
		"QualityColorrarity4"								"134 80 172 255"
		"QualityColorVintage"								"71 98 145 255"
		"QualityColorUnique"								"255 215 0 255"
		"QualityColorCommunity"								"112 176 74 255"
		"QualityColorDeveloper"								"165 15 121 255"
		"QualityColorSelfMade"								"112 176 74 255"
		"QualityColorCustomized"							"71 98 145 255"
		"QualityColorStrange"								"207 106 50 255"
		"QualityColorCompleted"								"134 80 172 255"
		"QualityColorHaunted"								"56 243 171 255"
		"QualityColorCollectors"							"170 0 0 255"
		"QualityColorPaintkitWeapon"						"250 250 250 255"

		"ItemRarityDefault"									"131 126 119 255"
		"ItemRarityCommon"									"176 195 217 255"
		"ItemRarityUncommon"								"94 152 217 255"
		"ItemRarityRare"									"75 105 255 255"
		"ItemRarityMythical"								"136 71 255 255"
		"ItemRarityLegendary"								"211 44 230 255"
		"ItemRarityAncient"									"235 75 75 255"

		"ItemRarityDefault_GreyedOut"						"44 42 40 255"
		"ItemRarityCommon_GreyedOut"						"59 65 72 255"
		"ItemRarityUncommon_GreyedOut"						"31 50 72 255"
		"ItemRarityRare_GreyedOut"							"25 35 85 255"
		"ItemRarityMythical_GreyedOut"						"45 24 85 255"
		"ItemRarityLegendary_GreyedOut"						"70 15 77 255"
		"ItemRarityAncient_GreyedOut"						"78 25 25 255"

		"QualityColorNormal_GreyedOut"						"44 44 44 255"
		"QualityColorrarity1_GreyedOut"						"20 29 21 255"
		"QualityColorrarity2_GreyedOut"						"35 33 19 255"
		"QualityColorrarity3_GreyedOut"						"51 51 62 255"
		"QualityColorrarity4_GreyedOut"						"36 20 43 255"
		"QualityColorVintage_GreyedOut"						"18 25 36 255"
		"QualityColorUnique_GreyedOut"						"64 54 0  255"
		"QualityColorCommunity_GreyedOut"					"28 44 19 255"
		"QualityColorDeveloper_GreyedOut"					"41 4  30  255"
		"QualityColorSelfMade_GreyedOut"					"28 44 74 255"
		"QualityColorCustomized_GreyedOut"					"71 98 19 255"
		"QualityColorStrange_GreyedOut"						"52 27 13 255"
		"QualityColorCompleted_GreyedOut"					"34 20 43 255"
		"QualityColorHaunted_GreyedOut"						"14 61 43 255"
		"QualityColorCollectors_GreyedOut"					"60 0 0 255"
		"QualityColorPaintkitWeapon_GreyedOut"				"60 60 60 255"

		"SaleGreen"											"76 107 34 255"

		"LightRed"											"80 190 233 225"
		"LighterRed"										"80 190 233 225"
		"LighterDarkBrown"									"60 60 60 255"
		"DarkBrown"											"30 30 30 255"

		"UpgradeDefaultFg"									"255 255 255 255"
		"UpgradeDefaultBg"									"60 60 60 255"
		"UpgradeArmedFg"									"255 255 255 255"
		"UpgradeArmedBg"									"80 190 233 225"
		"UpgradeDepressedFg"								"60 60 60 255"
		"UpgradeDepressedBg"								"80 190 233 225"
		"UpgradeSelectedFg"									"60 60 60 255"
		"UpgradeSelectedBg"									"80 190 233 225"
		"UpgradeDisabledFg"									"60 60 60 255"
		"UpgradeDisabledBg"									"0 0 0 255"
	}

	"BaseSettings"
	{
		"ReplayBrowser.BgColor"								"DarkBrown"
		"ReplayBrowser.Details.TitleEdit.Carat.FgColor"		"LightRed"
		"ReplayBrowser.Button.ArmedBgColor"					"TFOrange"
		"ReplayBrowser.Button.DepressedBgColor"				"TFOrange"
		"ReplayBrowser.CollectionTitle.FgColor"				"LightRed"
		"ReplayBrowser.Warning.FgColor"						"White"
		"ReplayBrowser.ScrollBar.SliderButton.FgColor"		"TransparentYellow"
		"ReplayBrowser.Search.BgColor"						"TanDark"
		"ReplayBrowser.Search.FgColor"						"White"

		"Replay.RenderDialog.BgColor"						"LighterDarkBrown"

		"Econ.Dialog.BgColor"								"Blank"
		"Econ.Button.BgColor"								"TanDark"
		"Econ.Button.FgColor"								"TanLight"
		"Econ.Button.ArmedBgColor"							"TFOrange"
		"Econ.Button.ArmedFgColor"							"TanLight"
		"Econ.Button.DepressedBgColor"						"TFOrange"
		"Econ.Button.DepressedFgColor"						"Black"

		"Econ.Button.PresetDefaultColorFg"					"TanLight"
		"Econ.Button.PresetArmedColorFg"					"TanLight"
		"Econ.Button.PresetDepressedColorFg"				"TanLight"

		"Econ.Button.PresetDefaultColorBg"					"LighterRed"
		"Econ.Button.PresetArmedColorBg"					"LightRed"
		"Econ.Button.PresetDepressedColorBg"				"TFOrange"

		"Border.Bright"										"Blank"
		"Border.Dark"										"Black"
		"Border.Selection"									"Gray"

		"Button.TextColor"									"TanLight"
		"Button.BgColor"									"TanDark"
		"Button.ArmedTextColor"								"TanLight"
		"Button.ArmedBgColor"								"TFOrange"
		"Button.SelectedTextColor"							"TanLight"
		"Button.SelectedBgColor"							"TFOrange"
		"Button.DepressedTextColor"							"Black"
		"Button.DepressedBgColor"							"TFOrange"

		"CheckButton.TextColor"								"Yellow"
		"CheckButton.SelectedTextColor"						"Yellow"
		"CheckButton.BgColor"								"TransparentBlack"
		"CheckButton.Border1"  								"Yellow"
		"CheckButton.Border2" 								"Yellow"
		"CheckButton.Check"									"Yellow"
		"CheckButton.HighlightFgColor"						"Yellow"

		"ComboBoxButton.ArrowColor"							"TanLight"
		"ComboBoxButton.ArmedArrowColor"					"TanLight"
		"ComboBoxButton.BgColor"							"Blank"
		"ComboBoxButton.DisabledBgColor"					"Blank"

		"Frame.BgColor"										"TransparentBlack"
		"Frame.OutOfFocusBgColor"							"TransparentBlack"
		"Frame.FocusTransitionEffectTime"					"0.0"
		"Frame.TransitionEffectTime"						"0.0"
		"Frame.AutoSnapRange"								"0"
		"FrameGrip.Color1"									"Blank"
		"FrameGrip.Color2"									"Blank"
		"FrameTitleButton.FgColor"							"Blank"
		"FrameTitleButton.BgColor"							"Blank"
		"FrameTitleButton.DisabledFgColor"					"Blank"
		"FrameTitleButton.DisabledBgColor"					"Blank"
		"FrameSystemButton.FgColor"							"Blank"
		"FrameSystemButton.BgColor"							"Blank"
		"FrameSystemButton.Icon"							""
		"FrameSystemButton.DisabledIcon"					""
		"FrameTitleBar.TextColor"							"Orange"
		"FrameTitleBar.BgColor"								"Blank"
		"FrameTitleBar.DisabledTextColor"					"Orange"
		"FrameTitleBar.DisabledBgColor"						"Blank"

		"GraphPanel.FgColor"								"Orange"
		"GraphPanel.BgColor"								"TransparentBlack"

		"Label.TextDullColor"								"TanDark"
		"Label.TextColor"									"TanLight"
		"Label.TextBrightColor"								"TanLight"
		"Label.SelectedTextColor"							"White"
		"Label.BgColor"										"Blank"
		"Label.DisabledFgColor1"							"Blank"
		"Label.DisabledFgColor2"							"Black"

		"ListPanel.TextColor"								"Orange"
		"ListPanel.BgColor"									"TransparentBlack"
		"ListPanel.SelectedTextColor"						"Black"
		"ListPanel.SelectedBgColor"							"Red"
		"ListPanel.SelectedOutOfFocusBgColor"				"Red"
		"ListPanel.EmptyListInfoTextColor"					"Orange"

		"Menu.TextColor"									"TanLight"
		"Menu.BgColor"										"TransparentBlack"
		"Menu.ArmedTextColor"								"TanDark"
		"Menu.ArmedBgColor"									"TanLight"
		"Menu.TextInset"									"6"

		"Chat.TypingText"									"Orange"

		"Panel.FgColor"										"Gray"
		"Panel.BgColor"										"Blank"

		"HTML.BgColor"										"Blank"

		"ProgressBar.FgColor"								"White"
		"ProgressBar.BgColor"								"0 0 0 50"

		"CircularProgressBar.FgColor"						"White"
		"CircularProgressBar.BgColor"						"White"

		"BuildingHealthBar.BgColor"							"HealthBgGrey"
		"BuildingHealthBar.Health"							"ProgressOffWhite"
		"BuildingHealthBar.LowHealth"						"LowHealthRed"

		"PropertySheet.TextColor"							"Orange"
		"PropertySheet.SelectedTextColor"					"Orange"
		"PropertySheet.TransitionEffectTime"				"0.25"
		"RadioButton.TextColor"								"Orange"
		"RadioButton.SelectedTextColor"						"Orange"

		"RichText.TextColor"								"Gray"
		"RichText.BgColor"									"Blank"
		"RichText.SelectedTextColor"						"Gray"
		"RichText.SelectedBgColor"							"Red"

		"ScrollBarButton.FgColor"							"Gray"
		"ScrollBarButton.BgColor"							"Blank"
		"ScrollBarButton.ArmedFgColor"						"Gray"
		"ScrollBarButton.ArmedBgColor"						"Blank"
		"ScrollBarButton.DepressedFgColor"					"Black"
		"ScrollBarButton.DepressedBgColor"					"Blank"

		"ScrollBarSlider.FgColor"							"Gray"
		"ScrollBarSlider.BgColor"							"Blank"

		"SectionedListPanel.HeaderTextColor"				"Orange"
		"SectionedListPanel.HeaderBgColor"					"Blank"
		"SectionedListPanel.DividerColor"					"Black"
		"SectionedListPanel.TextColor"						"Orange"
		"SectionedListPanel.BrightTextColor"				"Orange"
		"SectionedListPanel.BgColor"						"TransparentLightBlack"
		"SectionedListPanel.SelectedTextColor"				"Black"
		"SectionedListPanel.SelectedBgColor"				"Red"
		"SectionedListPanel.OutOfFocusSelectedTextColor"	"Black"
		"SectionedListPanel.OutOfFocusSelectedBgColor"		"255 255 255 32"

		"Slider.NobColor"									"108 108 108 255"
		"Slider.TextColor"									"127 140 127 255"
		"Slider.TrackColor"									"31 31 31 255"
		"Slider.DisabledTextColor1"							"117 117 117 255"
		"Slider.DisabledTextColor2"							"30 30 30 255"

		"TextEntry.TextColor"								"Gray"
		"TextEntry.BgColor"									"Blank"
		"TextEntry.CursorColor"								"Gray"
		"TextEntry.DisabledTextColor"						"Gray"
		"TextEntry.DisabledBgColor"							"Blank"
		"TextEntry.SelectedTextColor"						"TanLight"
		"TextEntry.SelectedBgColor"							"Gray"
		"TextEntry.OutOfFocusSelectedBgColor"				"Blank"
		"TextEntry.FocusEdgeColor"							"Blank"

		"ToggleButton.SelectedTextColor"					"Orange"

		"Tooltip.TextColor"									"TransparentBlack"
		"Tooltip.BgColor"									"Red"

		"TreeView.BgColor"									"TransparentBlack"

		"WizardSubPanel.BgColor"							"Blank"

		"TimerProgress.Active"								"HudTimerProgressActive"
		"TimerProgress.InActive"							"HudTimerProgressInActive"
		"TimerProgress.Warning"								"HudTimerProgressWarning"

		"HudObjectives.FgColor"								"HudPanelForeground"
		"HudObjectives.BgColor"								"HudPanelBackground"
		"HudObjectives.BorderColor"							"HudPanelBorder"

		"HudProgressBar.Active"								"HudProgressBarActive"
		"HudProgressBar.InActive"							"HudProgressBarInActive"

		"HudCaptureIcon.Active"								"HudProgressBarActive"
		"HudCaptureIcon.InActive"							"HudProgressBarInActive"
		"HudCaptureProgressBar.Active"						"HudProgressBarActive"
		"HudCaptureProgressBar.InActive"					"HudProgressBarInActive"

		"FgColor"											"White"
		"BgColor"											"TransparentBlack"

		"ViewportBG"										"Blank"
		"TeamSpec"											"204 204 204 255"
		"TeamRed"											"255 64 64 255"
		"TeamBlue"											"153 204 255 255"

		"MapDescriptionText"								"Gray"
		"HudIcon_Green"										"0 160 0 255"
		"HudIcon_Red"										"160 0 0 255"

		"ItemColor"											"255 167 42 200"
		"MenuColor"											"233 208 173 255"
		"MenuBoxBg"											"0 0 0 100"

		"SelectionNumberFg"									"255 255 255 255"
		"SelectionTextFg"									"255 255 255 255"
		"SelectionEmptyBoxBg" 								"0 0 0 80"
		"SelectionBoxBg" 									"0 0 0 80"
		"SelectionSelectedBoxBg" 							"0 0 0 190"

		"HintMessageFg"										"255 255 255 255"
		"HintMessageBg" 									"0 0 0 60"

		"ProgressBarFg"										"255 30 13 255"

		"Main.Menu.X"										"32"
		"Main.Menu.Y"										"248"

		"Main.BottomBorder"									"32"

		"VguiScreenCursor"									"255 208 64 255"
	}

	"BitmapFontFiles"
	{
		"Buttons"											"materials/vgui/fonts/buttons_32.vbf"
		"ButtonsSC"											"materials/vgui/fonts/buttons_sc.vbf"
	}
}