"Resource/UI/HudObjectiveStatus.res"
{	}