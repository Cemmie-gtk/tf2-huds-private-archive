#base "../base_unavailable_teleport_target.res"

"Resource/UI/build_menu/base_unavailable.res"
{
	"ItemNameLabel"
	{
		"fgcolor"		"ahudPipBoy"
	}

	"CantBuildReason"
	{
		"fgcolor"		"ahudPipBoy"
	}
}