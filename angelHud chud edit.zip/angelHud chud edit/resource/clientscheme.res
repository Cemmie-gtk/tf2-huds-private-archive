// Don't edit these lines

#base "scheme/basesettings.res"
#base "scheme/borders.res"
#base "scheme/colors.res"
#base "scheme/fonts.res"
#base "scheme/xhairs.res"

// If you want to edit the colors of the HUD
// go to resource/scheme/colors.res and edit
// the colors in that file

Scheme
{
	CustomFontFiles
	{
		"1" "resource/tf.ttf"
		"2" "resource/tfd.ttf"
		"3"
		{
			"font" "resource/TF2.ttf"
			"name" "TF2"
		}
		"4"
		{
			"font" "resource/TF2Secondary.ttf"
			"name" "TF2 Secondary"
		}
		"5"
		{
			"font" "resource/TF2Professor.ttf"
			"name" "TF2 Professor"
		}
		"6"
		{
			"font" "resource/TF2Build.ttf"
			"name" "TF2 Build"
		}
		"7"
		{
			"font" "resource/fonts/Blocks.ttf"
			"name" "Blocks"
		}
		"8"
		{
			"font"	"resource/fonts/FreeSerif.ttf"
			"name"	"FreeSerif"
		}
		"9"
		{
			"font"	"resource/fonts/FreeSerif.ttf"
			"name"	"FreeSerif"
		}
		"10"
		{
			"font" "resource/fonts/KnucklesCrosses.ttf"
			"name" "KnucklesCrosses"
		}
		"11"
		{
			"font" "resource/fonts/OMORI_GAME2.ttf"
			"name" "OMORI_GAME2"
		}
	}
}